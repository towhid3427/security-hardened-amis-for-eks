#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_remote_rsyslog_messages_only_accepted_designated_host.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/11/20    Recommendation "Ensure remote rsyslog messages are only accepted on designated log hosts"
# Justin Brown       05/11/22    Updated to modern format. Added passing criteria.
#
 
ensure_remote_rsyslog_messages_only_accepted_designated_host()
{
   echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
   test=""
   
   ensure_remote_rsyslog_messages_only_accepted_designated_host_chk()
   {
      l_output="" l_test1="" l_test2=""
      
      echo -e "- Start check - Ensure remote rsyslog messages are only accepted on designated log hosts" | tee -a "$LOG" 2>> "$ELOG"
   
      if grep '^\s*$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 1>>/dev/null; then
         l_output="\$ModLoad imtcp was found in:\n$(grep '^\s*$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf)"
      else
         l_test1=passed
         l_output="\$ModLoad imtcp was NOT found in /etc/rsyslog.conf or /etc/rsyslog.d/*.conf"
      fi
      
      if grep '^\s*$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 1>>/dev/null; then
         l_output="$l_output\n\$InputTCPServerRun was found in:\n$(grep '^\s*$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf)"
      else
         l_test2=passed
         l_output="$l_output\n\$InputTCPServerRun was NOT found in /etc/rsyslog.conf or /etc/rsyslog.d/*.conf"
      fi
      
      if [ "$l_test1" = passed ] && [ "$l_test2" = passed ]; then
			echo -e "- PASS:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure remote rsyslog messages are only accepted on designated log hosts" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure remote rsyslog messages are only accepted on designated log hosts" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi   
   }
   
   ensure_remote_rsyslog_messages_only_accepted_designated_host_fix()
   {
      echo -e "- Start remediation - Ensure rsyslog is installed" | tee -a "$LOG" 2>> "$ELOG"
      
      if grep '$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 1>>/dev/null; then
         for l_file in $(grep '^\s*$ModLoad imtcp' /etc/rsyslog.conf /etc/rsyslog.d/*.conf | awk -F: '{print $1}'); do
            echo -e "- Commenting out \$ModLoad imtcp from $l_file" | tee -a "$LOG" 2>> "$ELOG"
            sed -E -i 's/^\s*\$ModLoad imtcp/# $ModLoad imtcp/g' $l_file
         done
      fi
      
      if grep '$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf 1>>/dev/null; then
         for l_file in $(grep '^\s*$InputTCPServerRun' /etc/rsyslog.conf /etc/rsyslog.d/*.conf | awk -F: '{print $1}'); do
            echo -e "- Commenting out \$InputTCPServerRun imtcp from $l_file" | tee -a "$LOG" 2>> "$ELOG"
            sed -E -i 's/^\s*\$InputTCPServerRun/# $InputTCPServerRun/g' $l_file
         done
      fi
      
      test=remediated
      
      echo -e "- End remediation - Ensure rsyslog is installed" | tee -a "$LOG" 2>> "$ELOG"
   }
   
   ensure_remote_rsyslog_messages_only_accepted_designated_host_chk
	if [ "$?" = "101" ]; then
		[ -z "$test" ] && test="passed"
	else
      ensure_remote_rsyslog_messages_only_accepted_designated_host_fix
      ensure_remote_rsyslog_messages_only_accepted_designated_host_chk
	fi
	
	# Set return code, end recommendation entry in verbose log, and return
	case "$test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}