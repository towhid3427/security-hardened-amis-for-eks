#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_authentication_singleuser_mode.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       09/16/20    Recommendation "Ensure authentication required for single user mode"
# David Neilson	   05/20/22	 	Updated to current standards
# Justin Brown			09/03/22		Small syntax changes

authentication_singleuser_mode()
{
	# Use this function to determine which Linux OS the script is running on.
	nix_package_manager_set()
	{
		echo -e "- Start - Determine system's package manager " | tee -a "$LOG" 2>> "$ELOG"

		if command -v rpm 2>/dev/null; then
			echo -e "- system is rpm based" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="rpm -q"
			command -v yum 2>/dev/null && G_PM="yum" && echo "- system uses yum package manager" | tee -a "$LOG" 2>> "$ELOG"
			command -v dnf 2>/dev/null && G_PM="dnf" && echo "- system uses dnf package manager" | tee -a "$LOG" 2>> "$ELOG"
			command -v zypper 2>/dev/null && G_PM="zypper" && echo "- system uses zypper package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PR="$G_PM -y remove"
			export G_PQ G_PM G_PR
			echo -e "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		elif command -v dpkg 2>/dev/null; then
			echo -e "- system is apt based\n- system uses apt package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="dpkg -s"
			G_PM="apt"
			G_PR="$G_PM -y purge"
			export G_PQ G_PM G_PR
			echo -e "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL:\n- Unable to determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			G_PQ="unknown"
			G_PM="unknown"
			export G_PQ G_PM G_PR
			echo -e "- End - Determine system's package manager" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}		

	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""
	l_test1=""
	l_test2=""	
	l_test3=""

	authentication_singleuser_mode_chk()
	{
		l_output=""
		l_pkgmgr=""

		# Set package manager information
		if [ -z "$G_PQ" ] || [ -z "$G_PM" ] || [ -z "$G_PR" ]; then
			nix_package_manager_set
			[ "$?" != "101" ] && l_output="- Unable to determine the Linux distribution running on the system"
		fi	

		if [ -z "$l_output" ]; then
			# If the package manager is dpkg, we run the following check.  If there is any output, we fail:
			if echo "$G_PQ" | grep dpkg > /dev/null; then	
				if grep -Eq '^root:\$[0-9]' /etc/shadow; then
					l_test3="failed"
				else
					l_test3="passed"
				fi
			# If the package manager is NOT dpkg, run the following checks.
			else	
				# Test rescue.service
				if grep -Eq '^\s*ExecStart=-/bin/sh\s*-c\s+"/sbin/sulogin;\s+/usr/bin/systemctl\s+--fail\s+--no-block\s+default\s*"' /usr/lib/systemd/system/rescue.service; then
					l_test1="passed"
				else
					l_test1="failed"
				fi

				# Test emergency.service
				if grep -Eq '^\s*ExecStart=-/bin/sh\s+-c\s+"/sbin/sulogin;\s+/usr/bin/systemctl\s+--fail\s+--no-block\s+default\s*"' /usr/lib/systemd/system/emergency.service; then
					l_test2="passed"
				else
					l_test2="failed"
				fi
			fi
		else
			# If we can't determine the Linux distribution, need manual remediation
			l_pkgmgr="$l_output"
			echo -e "- FAILED:\n- $l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-106}"
		fi

		# If $l_test1 and $l_test2 both equal "passed", we pass.
		if [ "$l_test3" = "passed" ]; then
			echo -e "- PASS:\n- authentication required for single user mode is set correctly"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - single user mode authentication" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		elif [ "$l_test3" = "failed" ]; then
			l_pkgmgr="$l_output"
			echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- improper authentication set for single user mode"  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-106}"
		elif [ "$l_test1" = "passed" -a "$l_test2" = "passed" ]; then
			echo -e "- PASS:\n- authentication required for single user mode is set correctly"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - single user mode authentication" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_PASS:-101}"
		else
			# print the reason why we are failing
		   	echo "- FAILED:"  | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- improper authentication set for single user mode"  | tee -a "$LOG" 2>> "$ELOG"
		   	echo "- End check - single user mode authentication" | tee -a "$LOG" 2>> "$ELOG"
		   	return "${XCCDF_RESULT_FAIL:-102}"
		fi	 
	}

	authentication_singleuser_mode_fix()
	{
		# If we are running on a Linux distribution using dpkg, no automated action can be taken
		if echo "$G_PQ" | grep dpkg > /dev/null; then
			:
		else
			# If we are running on a Linux distribution NOT using dpkg, we can remediate
			# Fix rescue.service
			if [ "$l_test1" = "failed" ]; then
				# Comment out the existing "ExecStart=" line if it is not correct, then append the correct line to the existing file right after the line we just commented out 
				if grep -Eq '^\s*ExecStart=' /usr/lib/systemd/system/rescue.service; then
					sed -ri 's/(^\s*ExecStart=.*)$/# \1/' /usr/lib/systemd/system/rescue.service
					sed -ri '/^\s*#\s*ExecStart=.*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/rescue.service
				else
					# If an "ExecStart=" line exists that is commented out, append the correct line immediately after it
					if grep -Eq '^\s*#\s*ExecStart=' /usr/lib/systemd/system/rescue.service; then
						sed -ri '/^\s*#\s*ExecStart=.*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/rescue.service
					else
					# In this case, there is no "ExecStart=" line at all, so just append the correct line immediately after "[Service]"
						sed -ri '/\[Service\].*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/rescue.service
					fi
				fi
			fi	

			# Fix emergency.service
			if [ "$l_test2" = "failed" ]; then
				if grep -Eq '^\s*ExecStart=' /usr/lib/systemd/system/emergency.service; then
					sed -ri 's/(^\s*ExecStart=.*)$/# \1/' /usr/lib/systemd/system/emergency.service
					sed -ri '/^\s*#\s*ExecStart=.*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/emergency.service
				else
					if grep -Eq '^\s*#\s*ExecStart=' /usr/lib/systemd/system/emergency.service; then
						sed -ri '/^\s*#\s*ExecStart=.*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/emergency.service
					else
						sed -ri '/\[Service\].*/a ExecStart=-/bin/sh -c "/sbin/sulogin; /usr/bin/systemctl --fail --no-block default"' /usr/lib/systemd/system/emergency.service
					fi
				fi
			fi
		fi	
	}

	authentication_singleuser_mode_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ -n "$l_pkgmgr" ] ; then
		l_test="manual"
	else
		authentication_singleuser_mode_fix
		authentication_singleuser_mode_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}