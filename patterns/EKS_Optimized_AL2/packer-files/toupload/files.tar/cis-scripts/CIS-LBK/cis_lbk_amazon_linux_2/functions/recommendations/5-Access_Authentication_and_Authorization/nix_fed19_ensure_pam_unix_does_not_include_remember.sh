#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_pam_unix_does_not_include_remember.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus        01/31/2024   Recommendation "Ensure pam_unix does not include remember"
# 

fed19_ensure_pam_unix_does_not_include_remember()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - Ensure pam_unix does not include remember \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed19_ensure_pam_unix_does_not_include_remember_chk()
    {
        echo -e "- Start check - Ensure pam_unix does not include remember" | tee -a "$LOG" 2>> "$ELOG"

       # Check if pam_unix is used and does not include remember
        if grep -Pi -- '^\h*(auth|account|password|session)\h+(required|requisite|sufficient)\h+pam_unix\.so\b' /etc/pam.d/{password,system}-auth | grep -Pq '\bremember=\b'; then
            echo -e "- FAIL: pam_unix includes remember" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- The following lines include remember:\n$(grep -P -- '^\h*(auth|account|password|session)\h+(required|requisite|sufficient)\h+pam_unix\.so\b' /etc/pam.d/{password,system}-auth | grep -P '\bremember=\b')" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_unix does not include remember" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        else
            echo -e "- PASS: pam_unix does not include remember" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_unix does not include remember" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        fi
    }

    fed19_ensure_pam_unix_does_not_include_remember_fix()
    {
        echo -e "- Start remediation - Ensure pam_unix includes remember" | tee -a "$LOG" 2>> "$ELOG"

        for file in "/etc/pam.d/password-auth" "/etc/pam.d/system-auth"; do
            if grep -Pi '^\h*(auth|account|password|session)\h+(required|requisite|sufficient)\h+pam_unix\.so\b' $file | grep -Pq '\bremember=\d\b'; then
                echo -e "- Removing 'remember' entries from $file" | tee -a "$LOG" 2>> "$ELOG"
                sed -ri 's/(^\s*(auth|account|password|session)\s+(required|requisite|sufficient)\s+pam_unix\.so\s+)([^#\n\r]+\s+)?(remember=[0-9]+\s*)(.*)?$/\1\3\5/g' $file
            fi
        done

        echo -e "- End remediation - Ensure pam_unix includes remember" | tee -a "$LOG" 2>> "$ELOG"

    }

    fed19_ensure_pam_unix_does_not_include_remember_chk
    if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
        fed19_ensure_pam_unix_does_not_include_remember_fix
        if [ "$l_test" != "manual" ]; then
            fed19_ensure_pam_unix_does_not_include_remember_chk
            if [ "$?" = "101" ]; then
                [ "$l_test" != "failed" ] && l_test="remediated"

            fi
        fi
    fi

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac

}