#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_journald_configured_send_logs_rsyslog.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus       01/11/24    Recommendation "Ensure journald is configured to send logs to rsyslog"
# 

fed19_ensure_journald_configured_send_logs_rsyslog()
{
   echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
   l_test=""
   
   fed19_ensure_journald_configured_send_logs_rsyslog_chk()
   {
      echo -e "- Start check - Ensure journald is not configured to send logs to rsyslog" | tee -a "$LOG" 2>> "$ELOG"
      l_output="" # Positive  result
	  l_output2="" # Everything else
 
	  if pgrep rsyslogd >/dev/null 2>&1 && ! pgrep -x systemd-journald >/dev/null 2>&1; then
			echo -e "- rsyslog is being used instead of systemd-journald." | tee -a "$LOG" 2>> "$ELOG"
		if  grep -Piq -- '^\s*ForwardToSyslog\s*=\s*yes' /etc/systemd/journald.conf; then
         	l_output="$l_output\n - ForwardToSyslog=yes is found in /etc/systemd/journald.conf"
			
        else
            l_output2="$l_output2\n - ForwardToSyslog=yes was not found in /etc/systemd/journald.conf" 
        fi

		if systemctl list-units --type service | grep -P -- '(journald|rsyslog)' > /dev/null 2>&1; then
			l_output="$l_output\n Both rsyslog.service and systemd-journald.service are running."
			#l_output="$l_output\n $(systemctl list-units --type service | grep -P -- '(journald|rsyslog)')"
		else
			l_output2="$l_output2\n Either rsyslog.service or systemd-journald.service is not running."
			l_output2="$l_output2\n $(systemctl list-units --type service | grep -P -- '(journald|rsyslog)')"
		fi

		if [ -z "$l_output2" ]; then # Provide output from checks
			echo -e "\n- Audit Result:\n  ** PASS **\n$l_output\n"
			echo -e "- End check - Ensure journald is configured to send logs to rsyslog" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "\n- Audit Result:\n  ** FAIL **\n - Reason(s) for audit failure:\n$l_output2\n"
			[ -n "$l_output" ] && echo -e "\n- Correctly set:\n$l_output\n"
			echo -e "- End check - Ensure journald is configured to send logs to rsyslog" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi


	  else
			echo -e "- System is not using rsyslog or is using systemd-journald." | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- Recommendation Ensure journald is configured to send logs to rsyslog is NA"  | tee -a "$LOG" 2>> "$ELOG"
			l_test="NA"
	  fi

      
   
   }
   
   fed19_ensure_journald_configured_send_logs_rsyslog_fix()
      {
      	echo -e "- Start remediation - Ensure journald is configured to send logs to rsyslog" | tee -a "$LOG" 2>> "$ELOG"

		# edit the file /etc/systemd/journald.conf
		if grep -Eq '^\s*(#)?\s*[Ff]orward[Tt]o[Ss]yslog' /etc/systemd/journald.conf; then
			echo -e "- Fixing ForwardToSyslog entry in /etc/systemd/journald.conf" | tee -a "$LOG" 2>> "$ELOG"
			sed -E -i 's/^\s*(#)?\s*[Ff]orward[Tt]o[Ss]yslog.*$/ForwardToSyslog=yes/g' /etc/systemd/journald.conf
		else
			echo -e "- Adding ForwardToSyslog entry to /etc/systemd/journald.conf" | tee -a "$LOG" 2>> "$ELOG"
			echo "ForwardToSyslog=yes" >> /etc/systemd/journald.conf
		fi
		
		# Restart the systemd-journald service
		systemctl reload-or-try-restart systemd-journald.service

		echo -e "- End remediation - Ensure journald is configured to send logs to rsyslog" | tee -a "$LOG" 2>> "$ELOG"
   	  }
   
   fed19_ensure_journald_configured_send_logs_rsyslog_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else

		if [ "$l_test" != "NA" ]; then
      		fed19_ensure_journald_configured_send_logs_rsyslog_fix
	  		if [ "$l_test" != "manual" ]; then
			fed19_ensure_journald_configured_send_logs_rsyslog_chk
				if [ "$?" = "101" ]; then
				   [ "$l_test" != "failed" ] && l_test="remediated"
				fi
			fi
	  	fi
	fi
   
   # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}