#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_gpgcheck_globally_activated.sh
#
# Name                 Date        Description
# ------------------------------------------------------------------------------------------------
# J Brown              01/06/24    Recommendation "Ensure gpgcheck is globally activated"
#

fed19_ensure_gpgcheck_globally_activated()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed19_ensure_gpgcheck_globally_activated_chk()
	{
		l_output="" l_output2=""

		echo -e "- Start check - Ensure gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"

		# Check /etc/yum.conf
		if grep -Piq -- "^gpgcheck\h*=\h*[^1]\b" /etc/yum.conf; then
			l_output2="$l_output2\n- 'gpgcheck' is NOT configured correctly in /etc/yum.conf"
        else
            l_output="$l_output\n- 'gpgcheck' is configured correctly in /etc/yum.conf"
		fi

        # Check /etc/yum.repos.d/*
        if grep -Piq -- "^gpgcheck\h*=\h*[^1]\b" /etc/yum.repos.d/*.repo; then
			l_output2="$l_output2\n- 'gpgcheck' is NOT configured correctly in:\n $(grep -Pi -- "^gpgcheck\h*=\h*[^1]\b" /etc/yum.repos.d/*.repo)"
        else
            l_output="$l_output\n- 'gpgcheck' is configured correctly in all files in /etc/yum.repos.d/*"
		fi

		if [ -z "$l_output2" ]; then
			echo -e "- PASSED:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAILED:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
            if [ -n "$l_output" ]; then
                echo -e "- Passing values:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            fi
			echo -e "- End check -Ensure gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-102}"
		fi
	}

	fed19_ensure_gpgcheck_globally_activated_fix()
	{
		echo -e "- Start remediation - Ensure gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"

		if grep -Piq -- "^gpgcheck\h*=\h*[^1]\b" /etc/yum.conf; then
            echo "Updating 'gpgcheck' value in /etc/yum.conf"
            sed -i 's/^gpgcheck\s*=\s*.*/gpgcheck=1/' /etc/yum.conf
        fi

        if grep -Piq -- "^gpgcheck\h*=\h*[^1]\b" /etc/yum.repos.d/*.repo; then
            echo "Updating 'gpgcheck' values in /etc/yum.repos.d/*"
            find /etc/yum.repos.d/ -name "*.repo" -exec sed -ri 's/^gpgcheck\s*=\s*.*/gpgcheck=1/' {} \;
        fi

		echo -e "- End remediation - Ensure gpgcheck is globally activated" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed19_ensure_gpgcheck_globally_activated_chk
	if [ "$?" = "101" ] ; then
		[ -z "$l_test" ] && l_test="passed"
	else
        fed19_ensure_gpgcheck_globally_activated_fix
		fed19_ensure_gpgcheck_globally_activated_chk
		if [ "$?" = "101" ]; then
            [ -z "$l_test" ] && l_test="remediated"
        fi
    fi

	case "$l_test" in
        passed)
            echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
            ;;
        remediated)
            echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-103}"
            ;;
        manual)
            echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-106}"
            ;;
        NA)
            echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-104}"
            ;;
        *)
            echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
            ;;
    esac
}