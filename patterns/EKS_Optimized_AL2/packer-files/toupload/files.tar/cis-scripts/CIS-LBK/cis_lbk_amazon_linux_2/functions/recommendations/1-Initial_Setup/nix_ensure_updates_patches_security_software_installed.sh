#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_ensure_updates_patches_security_software_installed.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Eric Pinnell       10/26/20    Recommendation "Ensure updates, patches, and additional security software are installed"
# Justin Brown       04/18/22    Updated to modern format
#

ensure_updates_patches_security_software_installed()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	ensure_updates_patches_security_software_installed_chk()
	{
		echo -e "- Start check - Ensure updates, patches, and additional security software are installed" | tee -a "$LOG" 2>> "$ELOG"

		l_check_update="$(dnf check-update)"
		l_needs_reboot="$(dnf needs-restarting -r)"

		echo -e "- Updates:\n  $l_check_update\n- Reboot:\n  $l_needs_reboot"  | tee -a "$LOG" 2>> "$ELOG"
		echo -e "- End check - Ensure updates, patches, and additional securi1ty software are installed" | tee -a "$LOG" 2>> "$ELOG"
		return "${XCCDF_RESULT_FAIL:-102}"
	}

	ensure_updates_patches_security_software_installed_fix()
	{
		echo -e "- Start Remediation - Ensure updates, patches, and additional security software are installed" | tee -a "$LOG" 2>> "$ELOG"

		echo -e "- Use your package manager to update all packages on the system according to site policy.\n  The following command will install all available updates:\n  # dnf update\n  Once the update process is complete, verify if reboot is required to load changes.\n  dnf needs-restarting -r"  | tee -a "$LOG" 2>> "$ELOG"
		l_test="manual"

		echo -e "- End Remediation - Ensure updates, patches, and additional security software are installed" | tee -a "$LOG" 2>> "$ELOG"
	}

	ensure_updates_patches_security_software_installed_chk
	if [ "$?" = "101" ] ; then
		[ -z "$l_test" ] && l_test="passed"
	else
		ensure_updates_patches_security_software_installed_fix
		if [ "$l_test" != "manual" ] ; then
			ensure_updates_patches_security_software_installed_chk
			if [ "$?" = "101" ] ; then
				[ "$l_test" != "failed" ] && l_test="remediated"
			else
				l_test="failed"
			fi
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
    case "$l_test" in
        passed)
            echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
            ;;
        remediated)
            echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-103}"
            ;;
        manual)
            echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-106}"
            ;;
        NA)
            echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-104}"
            ;;
        *)
            echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
            ;;
    esac
}
