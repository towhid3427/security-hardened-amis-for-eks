#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_password_history_remember_configured.sh
# 
# Name                Date          Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus        01/22/2024      Recommendation "Ensure password history remember is configured"
#

fed19_ensure_password_history_remember_configured()
{
    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - Ensure password history remember is configured \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed19_ensure_password_history_remember_configured_chk()
    {
        echo -e "- Start check - Ensure password history remember is configured" | tee -a "$LOG" 2>> "$ELOG"
        l_output="" l_output2=""

        if grep -Pi -- '^\h*password\h+(required|requisite)\h+pam_pwhistory\.so\h+([^#\n\r]+\h+)?remember=(2[4-9]|[3-9][0-9]|[1-9][0-9]{2,})\b' /etc/pam.d/system-auth; then
            l_output="$l_output\n - password history "remember=" is correctly configured in /etc/pam.d/system-auth"
        else
            l_output2="$l_output2\n - password history "remember=" is NOT configured correctly in /etc/pam.d/system-auth"
        fi		

        if grep -Pi -- '^\h*password\h+(required|requisite)\h+pam_pwhistory\.so\h+([^#\n\r]+\h+)?remember=(2[4-9]|[3-9][0-9]|[1-9][0-9]{2,})\b' /etc/pam.d/password-auth; then
            l_output="$l_output\n - password history "remember=" is correctly configured in /etc/pam.d/password-auth"
        else
            l_output2="$l_output2\n - password history "remember=" is NOT configured correctly in /etc/pam.d/password-auth"
        fi
        
        if [ -z "$l_output2" ]; then
            echo -e "- PASS:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure password history remember is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else
            echo -e "- FAIL:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure password history remember is configured" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        fi 

    }

    fed19_ensure_password_history_remember_configured_fix()
    {
        echo -e "- Start remediation - Ensure password history remember is configured" | tee -a "$LOG" 2>> "$ELOG"

        for file in "/etc/pam.d/password-auth" "/etc/pam.d/system-auth"; do
            if ! grep -Piq -- '^\h*password\h+(required|requisite)\h+pam_pwhistory\.so\h+([^#\n\r]+\h+)?remember=(2[4-9]|[3-9][0-9]|[1-9][0-9]{2,})\b' $file; then
                if grep -Piq -- '^\h*password\h+(required|requisite)\h+pam_pwhistory\.so\h+([^#\n\r]+\h+)?remember=' $file; then
                    echo -e "- Updating password required pam_pwhistory.so 'remember=' entry in $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*password\s+(required|requisite)\s+pam_pwhistory\.so\s+)([^#\n\r]+\s+)?(remember=)([0-9]+)?(.*)/\1\3\424\6/g' $file
                elif grep -Piq -- '^\h*password\h+(required|requisite)\h+pam_pwhistory\.so\h+' $file; then
                    echo -e "- Adding 'remember=24' to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*password\s+(required|requisite)\s+pam_pwhistory\.so\s+.*)/\1 remember=24/g' $file
                else
                    echo -e "- Adding password required pam_pwhistory.so 'remember=24' to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri '/password\s+sufficient\s+pam_unix\.so/i password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' $file
                fi
            fi
        done

        echo -e "- End remediation - Ensure password history remember is configured" | tee -a "$LOG" 2>> "$ELOG"
    }
    
    fed19_ensure_password_history_remember_configured_chk
    if [ "$?" = "101" ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        fed19_ensure_password_history_remember_configured_fix
        fed19_ensure_password_history_remember_configured_chk
        if [ "$?" = "101" ]; then
            [ "$l_test" != "failed" ] && l_test="remediated"
        else
            l_test="failed"
        fi
    fi
    

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac       
}