#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_audit_backlog_limit_sufficient.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus       01/18/2024    Recommendation "Ensure audit_backlog_limit is sufficient"


fed19_ensure_audit_backlog_limit_sufficient()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed19_ensure_audit_backlog_limit_sufficient_chk()
	{
		echo -e "- Start check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
		l_output=""
		l_output2=""

		echo "Validating audit_backlog_limit setting in grubby --info=ALL"
		if grubby --info=ALL | grep -Po "\baudit_backlog_limit=\d+\b"; then
			l_output="$l_output\n audit_backlog_limit is set to a sufficient value in grubby --info=ALL"
		else
			l_output2="$l_output2\n audit_backlog_limit is NOT set to a sufficiently high value in grubby --info=ALL"
		fi

		echo "Validating audit_backlog_limit setting in /etc/default/grub"
		if grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"([^#\n\r]+\h+)?\baudit_backlog_limit=(819[2-9]|8[2-9][0-9]|9[0-9]{3}|[1-9][0-9]{4,})' /etc/default/grub; then
			l_output="$l_output\n audit_backlog_limit is set to a sufficient value in /etc/default/grub"
		else
			l_output2="$l_output2\n audit_backlog_limit is NOT set to a sufficiently high value in /etc/default/grub"
		fi

		# Determine if the audit_backlog_limit variable exists in the grub file, and if it is >= 8192.

		if [ -z "$l_output2" ]; then
			echo -e "- PASSED:\n$l_output\n" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAILED:\n- Failing values:\n$l_output2\n" | tee -a "$LOG" 2>> "$ELOG"
			    if [ -n "$l_output" ]; then
				echo -e "- Passing values:\n$l_output\n" | tee -a "$LOG" 2>> "$ELOG"
			    fi
			echo -e "- End check - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
				return "${XCCDF_RESULT_FAIL:-102}"
		fi


	}

	fed19_ensure_audit_backlog_limit_sufficient_fix()
	{
		echo -e "- Start remediation - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
		# Set audit_backlog_limit to 8192

		if ! grubby --info=ALL | grep -Po "\baudit_backlog_limit=\d+\b"; then
			grubby --update-kernel ALL --args 'audit_backlog_limit=8192'
			echo -e " Updating audit_backlog_limit in grubby" | tee -a "$LOG" 2>> "$ELOG"
		fi

		if ! grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"([^#\n\r]+\h+)?\baudit_backlog_limit=(819[2-9]|8[2-9][0-9]|9[0-9]{3}|[1-9][0-9]{4,})' /etc/default/grub; then
			if grep -Pq '^\s*GRUB_CMDLINE_LINUX="([^#]+\h+)?audit_backlog_limit=' /etc/default/grub; then
				echo -e "- Updating audit_backlog_limit value in /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
				sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=")(.*)?(audit_backlog_limit=)([0-9]+)?(.*)?$/\1\2\38192\5/' /etc/default/grub
			else
				if ! grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"' /etc/default/grub; then
					echo -e "- Adding 'GRUB_CMDLINE_LINUX=' line to /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
					echo -e "GRUB_CMDLINE_LINUX=\"audit_backlog_limit=8192\"" >> /etc/default/grub
				else
					echo -e "- Adding audit_backlog_limit=8192 value to /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
					sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=".*)("$)/\1 audit_backlog_limit=8192\2/' /etc/default/grub
				fi
			fi
		fi
		echo -e "- End remediation - Ensure audit_backlog_limit is sufficient" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed19_ensure_audit_backlog_limit_sufficient_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
		fed19_ensure_audit_backlog_limit_sufficient_fix
		fed19_ensure_audit_backlog_limit_sufficient_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}