#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_password_unlock_time_configured.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Justin Brown        01/10/24    Recommendation "Ensure lockout for failed password attempts is configured"
#

fed19_ensure_password_unlock_time_configured()
{
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed19_ensure_password_unlock_time_configured_chk()
	{
        echo -e "- Start check - Ensure lockout for failed password attempts is configured" | tee -a "$LOG" 2>> "$ELOG"
        l_output="" l_output2=""

        l_password_preauth="$(grep -Pi -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+preauth\h+([^#\n\r]+\h+)?unlock_time=' /etc/pam.d/password-auth)"
        [ -z "$l_password_preauth" ] && l_password_preauth="preauth unlock_time= not set in /etc/pam.d/password-auth"
        l_password_authfail="$(grep -Pi -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+authfail\h+([^#\n\r]+\h+)?unlock_time=' /etc/pam.d/password-auth)"
        [ -z "$l_password_authfail" ] && l_password_authfail="authfail unlock_time= not set in /etc/pam.d/password-auth"
        l_system_preauth="$(grep -Pi -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+preauth\h+([^#\n\r]+\h+)?unlock_time=' /etc/pam.d/system-auth)"
        [ -z "$l_system_preauth" ] && l_system_preauth="preauth unlock_time= not set in /etc/pam.d/system-auth"
        l_system_authfail="$(grep -Pi -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+authfail\h+([^#\n\r]+\h+)?unlock_time=' /etc/pam.d/system-auth)"
        [ -z "$l_system_authfail" ] && l_system_authfail="authfail unlock_time= not set in /etc/pam.d/system-auth"

        for test in "$l_password_preauth" "$l_password_authfail" "$l_system_preauth" "$l_system_authfail"; do
            if echo "$test" | grep -Piq -- 'unlock_time=(0|9[0-9][0-9]|[1-9][0-9]{3,})\b'; then
                l_output="$l_output\n  $test"
            else
                l_output2="$l_output2\n  $test"
            fi
        done

        if [ -z "$l_output2" ]; then
			echo -e "- PASS:\n- Passing values:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure lockout for failed password attempts is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAIL:\n- Failing values:\n$l_output2" | tee -a "$LOG" 2>> "$ELOG"
            if [ -n "$l_output" ]; then
                echo -e "- Passing values:\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            fi
			echo -e "- End check - Ensure lockout for failed password attempts is configured" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
		fi
    }

    fed19_ensure_password_unlock_time_configured_fix()
	{
        echo -e "- Start remediation - Ensure lockout for failed password attempts is configured" | tee -a "$LOG" 2>> "$ELOG"

        for file in "/etc/pam.d/password-auth" "/etc/pam.d/system-auth"; do
            if ! grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+preauth\h+([^#\n\r]+\h+)?unlock_time=(0|9[0-9][0-9]|[1-9][0-9]{3,})\b' $file; then
                if grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+preauth\h+([^#\n\r]+\h+)?unlock_time=' $file; then
                    echo -e "- Updating auth preauth 'unlock_time' entry in $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*auth\s+([^#\n\r]+)\s+pam_faillock\.so\s+preauth\s+([^#\n\r]+\s+)?unlock_time=)([0-9]+)(.*)/\1900 \3/g' $file
                elif grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+preauth' $file; then
                    echo -e "- Adding auth preauth 'unlock_time' entry to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*auth\s+([^#\n\r]+)\s+pam_faillock\.so\s+preauth\s+.*)/\1unlock_time=900/g' $file
                else
                    echo -e "- Adding auth preauth line to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri '/auth\s+required\s+pam_env.so/a auth        required      pam_faillock.so preauth silent audit deny=5 unlock_time=900 even_deny_root' $file
                fi
            fi

            if ! grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+authfail\h+([^#\n\r]+\h+)?unlock_time=time=(0|9[0-9][0-9]|[1-9][0-9]{3,})\b' $file; then
                if grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+authfail\h+([^#\n\r]+\h+)?unlock_time=' $file; then
                    echo -e "- Updating auth authfail 'unlock_time' entry in $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*auth\s+([^#\n\r]+)\s+pam_faillock\.so\s+authfail\s+([^#\n\r]+\s+)?unlock_time=)([0-9]+)(.*)/\1900 \3/g' $file
                elif grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_faillock\.so\h+authfail' $file; then
                    echo -e "- Adding auth authfail 'unlock_time' entry to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri 's/(^\s*auth\s+([^#\n\r]+)\s+pam_faillock\.so\s+authfail\s+.*)/\1unlock_time=900/g' $file
                else
                    if grep -Piq -- '^\h*auth\h+([^#\n\r]+)\h+pam_succeed_if\.so\b' $file; then
                        echo -e "- Adding auth authfail line to $file" | tee -a "$LOG" 2>> "$ELOG"
                        sed -ri '/auth\s+([^#\n\r]+)\s+pam_succeed_if\.so/a auth        [default=die]      pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' $file
                    else
                        echo -e "- Adding auth authfail line to $file" | tee -a "$LOG" 2>> "$ELOG"
                        sed -ri '/auth\s+required\s+pam_deny.so/i auth        [default=die]      pam_faillock.so authfail audit deny=5 unlock_time=900 even_deny_root' $file
                    fi
                fi
            fi
        done

        echo -e "- End remediation - Ensure lockout for failed password attempts is configured" | tee -a "$LOG" 2>> "$ELOG"
    }

    fed19_ensure_password_unlock_time_configured_chk
    if [ "$?" = "101" ]; then
        [ -z "$l_test" ] && l_test="passed"
    else
        if [ "$l_test" != "NA" ]; then
            fed19_ensure_password_unlock_time_configured_fix
            if [ "$l_test" != "manual" ] ; then
                fed19_ensure_password_unlock_time_configured_chk
                if [ "$?" = "101" ] ; then
                    [ "$l_test" != "failed" ] && l_test="remediated"
                else
                    l_test="failed"
                fi
            fi
        fi
    fi

	# Set return code and return
	case "$l_test" in
		passed)
			echo "Recommendation \"$RNA\" No remediation required" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo "Recommendation \"$RNA\" successfully remediated" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo "Recommendation \"$RNA\" requires manual remediation" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo "Recommendation \"$RNA\" Something went wrong - Recommendation is non applicable" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo "Recommendation \"$RNA\" remediation failed" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}