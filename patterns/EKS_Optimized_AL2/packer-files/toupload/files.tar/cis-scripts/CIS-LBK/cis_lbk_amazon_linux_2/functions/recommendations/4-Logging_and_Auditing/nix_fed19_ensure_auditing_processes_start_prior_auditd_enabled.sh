#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_auditing_processes_start_prior_auditd_enabled.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus       	 01/19/2024  Recommendation "Ensure auditing for processes that start prior to auditd is enabled"

fed19_ensure_auditing_processes_start_prior_auditd_enabled()
{
	# Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

	fed19_ensure_auditing_processes_start_prior_auditd_enabled_chk()
	{
		echo -e "- Start check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
		l_output=""
        l_output2=""

		echo "Validating audit=1 setting in grubby --info=ALL"
		if grubby --info=ALL | grep -Po '\baudit=1\b'; then
			l_output="$l_output\n audit=1 is set correctly in grubby --info=ALL"
		else
			l_output2="$l_output2\n audit=1 is NOT set correctly in grubby --info=ALL"
		fi

		echo "Validating audit=1 setting in /etc/default/grub"
        if grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"([^#\n\r]+\h+)?audit=1\b' /etc/default/grub; then
            l_output="$l_output\n audit=1 is set correctly in /etc/default/grub"
        else
            l_output2="$l_output2\n audit=1 is NOT set correctly in /etc/default/grub"
        fi

		# Determine if the audit variable exists in the grub file, and if it is = 1.

        if [ -z "$l_output2" ]; then
		    echo -e "- PASSED:\n$l_output\n" | tee -a "$LOG" 2>> "$ELOG"
			echo -e "- End check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
			    return "${XCCDF_RESULT_PASS:-101}"
		else
			echo -e "- FAILED:\n- Failing values:\n$l_output2\n" | tee -a "$LOG" 2>> "$ELOG"
			if [ -n "$l_output" ]; then
			    echo -e "- Passing values:\n$l_output\n" | tee -a "$LOG" 2>> "$ELOG"
			fi
            	echo -e "- End check - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
			        return "${XCCDF_RESULT_FAIL:-102}"
		fi
	}

	fed19_ensure_auditing_processes_start_prior_auditd_enabled_fix()
	{
		echo -e "- Start remediation - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
		if ! grubby --info=ALL | grep -Po '\baudit=1\b'; then
		     grubby --update-kernel ALL --args 'audit=1'
		     echo -e " Setting audit=1 in grubby" | tee -a "$LOG" 2>> "$ELOG"
		fi

		if ! grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"([^#\n\r]+\h+)?audit=1\b' /etc/default/grub; then
			if grep -Pq '^\s*GRUB_CMDLINE_LINUX="([^#]+\h+)?audit=' /etc/default/grub; then
				echo -e "- Setting audit=1 in /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
				sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=")(.*)?(audit=)([0-9]+)?(.*)?$/\1\2\31\5/' /etc/default/grub
		    else
				if ! grep -Psoi -- '^\h*GRUB_CMDLINE_LINUX=\"' /etc/default/grub; then
					echo -e "- Adding 'GRUB_CMDLINE_LINUX=' line to /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
					echo -e "GRUB_CMDLINE_LINUX=\"audit=1\"" >> /etc/default/grub
				else
					echo -e "- Adding audit=1 value to /etc/default/grub" | tee -a "$LOG" 2>> "$ELOG"
					sed -ri 's/(^\s*GRUB_CMDLINE_LINUX=".*)("$)/\1 audit=1\2/' /etc/default/grub
				fi
			fi
        fi
		echo -e "- End remediation - Ensure auditing for processes that start prior to auditd is enabled" | tee -a "$LOG" 2>> "$ELOG"
	}

	fed19_ensure_auditing_processes_start_prior_auditd_enabled_chk
	if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	elif [ "$l_test" = "manual" ]; then
		:
	else
		fed19_ensure_auditing_processes_start_prior_auditd_enabled_fix
		fed19_ensure_auditing_processes_start_prior_auditd_enabled_chk
		if [ "$?" = "101" ]; then
			[ "$l_test" != "failed" ] && l_test="remediated"
		else
			l_test="failed"
		fi
	fi

	# Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac
}