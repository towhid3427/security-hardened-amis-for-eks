#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm.sh
# 
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus        01/23/2024   Recommendation "Ensure pam_unix includes a strong password hashing algorithm"
#

fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm()
{

    echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - includes a strong password hashing algorithm \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
    l_test=""

    fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm_chk()
    {
        echo -e "- Start check - Ensure pam_unix includes a strong password hashing algorithm" | tee -a "$LOG" 2>> "$ELOG"
        l_output="" l_output2=""

        # Check password-auth file
        if grep -P -- '^\h*password\h+([^#\n\r]+)\h+pam_unix\.so\h+([^#\n\r]+\h+)?(sha512|yescrypt)\b' /etc/pam.d/password-auth; then
                l_output="$l_output\n - password hashing algorithm is correctly set to use either sha512 or yescrypt"
        else
                l_output2="$l_output2\n - password hashing algorithm is NOT correctly set in /etc/pam.d/password-auth"
        fi

        # Check system-auth file
        if grep -P -- '^\h*password\h+([^#\n\r]+)\h+pam_unix\.so\h+([^#\n\r]+\h+)?(sha512|yescrypt)\b' /etc/pam.d/system-auth; then
                l_output="$l_output\n - password hashing algorithm is correctly set to use either sha512 or yescrypt"
        else
                l_output2="$l_output2\n - password hashing algorithm is NOT correctly set in /etc/pam.d/system-auth"
        fi

        if [ -z "$l_output2" ]; then
            echo -e "- PASS: password hashing algorithm is correctly set to use either sha512 or yescrypt" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_unix includes a strong password hashing algorithm" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        else    
            echo -e "- FAIL: password hashing algorithim is NOT correctly set in \n$l_output2\n" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_unix includes a strong password hashing algorithm" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        fi                  

    }

    fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm_fix()
	{
      echo -e "- Start remediation - Ensure pam_unix includes a strong password hashing algorithm" | tee -a "$LOG" 2>> "$ELOG"
      l_sa_fix="" l_pa_fix=""
      
      # Set /etc/pam.d/system-auth
      if grep -Pq 'password\s+(\S+)\s+pam_unix\.so(\s+[^#]+\s+)?\s*(sha\d+\b)' /etc/pam.d/system-auth; then
         echo -e "- Updating password hashing entry in /etc/pam.d/system-auth" | tee -a "$LOG" 2>> "$ELOG"
         sed -ri 's/^\s*(#\s*)?(password\s+)(\S+)(\s+pam_unix\.so\s+)([^#]+\s+)?(sha[0-9]+\s)(.*)$/\2\3\4\5 sha512 \7/' /etc/pam.d/system-auth
		elif grep -Pq 'password\s+(\S+)\s+pam_unix\.so\s+' /etc/pam.d/system-auth; then
         echo -e "- Adding password hashing entry in /etc/pam.d/system-auth" | tee -a "$LOG" 2>> "$ELOG"
         sed -ri 's/^\s*(#\s*)?(password\s+)(\S+)(\s+pam_unix\.so\s+)([^#]+\s*)?(\s*#.*)?$/\2\3\4\5 sha512 \6/' /etc/pam.d/system-auth
		else
         echo -e "- Inserting password hashing entry in /etc/pam.d/system-auth" | tee -a "$LOG" 2>> "$ELOG"
			sed -ri '/password\s+(\S+)\s+pam_deny\.so\s*/i  password   sufficient   pam_unix.so sha512 shadow  use_authtok' /etc/pam.d/system-auth
		fi
         
		grep -Pq '^\s*password\s+(\S+\s+)+pam_unix\.so\s+([^#]+\s+)?sha512\b' /etc/pam.d/system-auth && l_sa_fix=remediated
      
      # Set /etc/pam.d/password-auth
      if grep -Pq 'password\s+(\S+)\s+pam_unix\.so(\s+[^#]+\s+)?\s*(sha\d+\b)' /etc/pam.d/password-auth; then
         echo -e "- Updating password hashing entry in /etc/pam.d/password-auth" | tee -a "$LOG" 2>> "$ELOG"
         sed -ri 's/^\s*(#\s*)?(password\s+)(\S+)(\s+pam_unix\.so\s+)([^#]+\s+)?(sha[0-9]+\s)(.*)$/\2\3\4\5 sha512 \7/' /etc/pam.d/password-auth
		elif grep -Pq 'password\s+(\S+)\s+pam_unix\.so\s+' /etc/pam.d/password-auth; then
         echo -e "- Adding password hashing entry in /etc/pam.d/password-auth" | tee -a "$LOG" 2>> "$ELOG"
         sed -ri 's/^\s*(#\s*)?(password\s+)(\S+)(\s+pam_unix\.so\s+)([^#]+\s*)?(\s*#.*)?$/\2\3\4\5 sha512 \6/' /etc/pam.d/password-auth
		else
         echo -e "- Inserting password hashing entry in /etc/pam.d/password-auth" | tee -a "$LOG" 2>> "$ELOG"
			sed -ri '/password\s+(\S+)\s+pam_deny\.so\s*/i  password   sufficient   pam_unix.so sha512 shadow  use_authtok' /etc/pam.d/password-auth
		fi
         
		grep -Pq '^\s*password\s+(\S+\s+)+pam_unix\.so\s+([^#]+\s+)?sha512\b' /etc/pam.d/password-auth && l_pa_fix=remediated
      
      if [ "$l_sa_fix" = remediated ] && [ "$l_pa_fix" = remediated ]; then
         l_test=remediated
      fi
      echo -e "- End remediation - Ensure pam_unix includes a strong password hashing algorithm" | tee -a "$LOG" 2>> "$ELOG"
   }

   fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm_chk
    if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
        fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm_fix
        if [ "$l_test" != "manual" ]; then
            fed19_ensure_pam_unix_includes_strong_password_hashing_algorithm_chk
            if [ "$?" = "101" ]; then
                [ "$l_test" != "failed" ] && l_test="remediated"
                
            fi
        fi    
    fi    

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac     

}