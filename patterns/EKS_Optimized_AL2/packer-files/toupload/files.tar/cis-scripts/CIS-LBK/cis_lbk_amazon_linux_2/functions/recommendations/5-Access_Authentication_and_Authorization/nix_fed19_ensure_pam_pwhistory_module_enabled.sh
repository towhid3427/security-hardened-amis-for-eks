#!/usr/bin/env bash
#
# CIS-LBK Recommendation Function
# ~/CIS-LBK/functions/recommendations/nix_fed19_ensure_pam_pwhistory_module_enabled.sh
#
# Name                Date       Description
# ------------------------------------------------------------------------------------------------
# Gokhan Lus       01/23/2024    Recommendation "Ensure pam_pwhistory module is enabled"
#

fed19_ensure_pam_pwhistory_module_enabled()
{
    # Start recommendation entry for verbose log and output to screen
	echo -e "\n**************************************************\n- $(date +%d-%b-%Y' '%T)\n- Start Recommendation - Ensure pam_pwhistory module is enabled \"$RN - $RNA\"" | tee -a "$LOG" 2>> "$ELOG"
	l_test=""

    fed19_ensure_pam_pwhistory_module_enabled_chk()
    {
        echo -e "- Start check - Ensure pam_pwhistory module is enabled" | tee -a "$LOG" 2>> "$ELOG"
        l_output=""

        # Verify pam_pwhistory in password-auth
        if ! grep -P -- '\bpam_pwhistory\.so\b' /etc/pam.d/password-auth; then
            l_output="$l_output\n - pam_pwhistory module is not set in /etc/pam.d/password-auth"
        fi

        # Verify pam_pwhistory in system-auth
        if ! grep -P -- '\bpam_pwhistory\.so\b' /etc/pam.d/system-auth; then
            l_output="$l_output\n - pam_pwhistory module is not set in /etc/pam.d/system-auth"
        fi

        if [ -n "$l_output" ]; then
            echo -e "- FAIL: pam_pwhistory module is NOT enabled\n$l_output" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_pwhistory module is enabled" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_FAIL:-102}"
        else 
            echo -e "- PASS: pam_pwhistory module is enabled" | tee -a "$LOG" 2>> "$ELOG"
            echo -e "- End check - Ensure pam_pwhistory module is enabled" | tee -a "$LOG" 2>> "$ELOG"
            return "${XCCDF_RESULT_PASS:-101}"
        fi 
    }

    fed19_ensure_pam_pwhistory_module_enabled_fix()
    {
        echo -e "- Start remediation - Ensure pam_pwhistory module is enabled" | tee -a "$LOG" 2>> "$ELOG"
        
        for file in "/etc/pam.d/password-auth" "/etc/pam.d/system-auth"; do
            if ! grep -Piq -- '\bpam_pwhistory\.so\b' $file; then
                    echo -e "- Adding 'password   required   pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' to $file" | tee -a "$LOG" 2>> "$ELOG"
                    sed -ri '/password\s+sufficient\s+pam_unix\.so/i password    required      pam_pwhistory.so remember=24 enforce_for_root try_first_pass use_authtok' $file
            fi
        done
    }
    fed19_ensure_pam_pwhistory_module_enabled_chk
     if [ "$?" = "101" ]; then
		[ -z "$l_test" ] && l_test="passed"
	else
        fed19_ensure_pam_pwhistory_module_enabled_fix
        if [ "$l_test" != "manual" ]; then
            fed19_ensure_pam_pwhistory_module_enabled_chk
            if [ "$?" = "101" ]; then
                [ "$l_test" != "failed" ] && l_test="remediated"
                
            fi
        fi    
    fi    

    # Set return code, end recommendation entry in verbose log, and return
	case "$l_test" in
		passed)
			echo -e "- Result - No remediation required\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-101}"
			;;
		remediated)
			echo -e "- Result - successfully remediated\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-103}"
			;;
		manual)
			echo -e "- Result - requires manual remediation\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-106}"
			;;
		NA)
			echo -e "- Result - Recommendation is non applicable\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_PASS:-104}"
			;;
		*)
			echo -e "- Result - remediation failed\n- End Recommendation \"$RN - $RNA\"\n**************************************************\n" | tee -a "$LOG" 2>> "$ELOG"
			return "${XCCDF_RESULT_FAIL:-102}"
			;;
	esac 

}